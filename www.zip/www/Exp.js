var callData = function() {
   alert("works");
};

document.querySelector('.sample').addEventListener("click", callData);