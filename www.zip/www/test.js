document.querySelector('.sample').addEventListener('click', function() {
    alert("works");
});